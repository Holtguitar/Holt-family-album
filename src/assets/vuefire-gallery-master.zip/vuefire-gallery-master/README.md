# vuefire-gallery

> Vuefire-gallery from Vuejs & Firebase tutorial : build gallery image app
<br /> part 1 - https://rayhanstar.blogspot.com/2020/06/vuejs-firebase-tutorial-build-image.html
<br /> part 2 - https://rayhanstar.blogspot.com/2020/06/vuejs-firebase-tutorial-build-image_11.html

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
